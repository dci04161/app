// 오픽 연습 서비스 워커: 온라인이면 항상 최신 파일(네트워크 우선), 오프라인이면 캐시 사용
const CACHE = 'opic-app-v6';
const SHELL = [
  './', './index.html', './manifest.webmanifest', './css/app.css',
  './js/app.js', './js/db.js', './js/settings.js', './js/ui.js', './js/recorder.js', './js/tts.js',
  './js/gemini.js', './js/aivoice.js', './js/bank.js', './js/sets.js', './js/scriptmap.js', './js/scripts.js', './js/questions.js', './js/exam.js', './js/analysis.js', './js/lookup.js', './js/stats.js',
  './js/views/home.js', './js/views/survey.js', './js/views/examstart.js', './js/views/practice.js', './js/views/runner.js',
  './js/views/attempt.js', './js/views/examples.js', './js/views/history.js', './js/views/weak.js', './js/views/vocab.js', './js/views/settings.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // Gemini 등 외부 요청은 건드리지 않음
  e.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req).then((r) => r || caches.match('./index.html')))
  );
});
